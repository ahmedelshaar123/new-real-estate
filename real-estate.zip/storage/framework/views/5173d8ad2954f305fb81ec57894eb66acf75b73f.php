<?php $staticPage = app('App\Models\Setting'); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <!-- form start -->
        <?php echo Form::model($staticPage,[
                                'action'=>['Admin\StaticPageController@update',$staticPage->id],
                                'id'=>'myForm',
                                'role'=>'form',
                                'method'=>'PUT',
                                'files'=>'true',
                                ]); ?>


        <div class="box-body">
            <?php echo $__env->make('layouts.partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php $__currentLoopData = $staticPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staticPage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-body">
                    <div class="form-group">
                        <?php if($staticPage->type == 'text'): ?>
                            <label for="<?php echo e($staticPage->key); ?>"><?php echo e($staticPage->$name); ?></label>
                            <?php echo Form::text($staticPage->key,$staticPage->$value,[
                                'class'=>'form-control',
                            ]); ?>

                            <br>
                        <?php elseif($staticPage->type == 'textarea'): ?>
                            <label for="<?php echo e($staticPage->key); ?>"><?php echo e($staticPage->$name); ?></label>
                            <?php echo Form::text($staticPage->key,$staticPage->$value,[
                                'class'=>'form-control myTextArea',
                            ]); ?>

                            <br>
                        <?php elseif($staticPage->type == 'image'): ?>
                            <label for="image"><?php echo e($staticPage->$name); ?></label>
                            <input <?php if($staticPage->key == 'vision_image'): ?> name="vision_image" <?php elseif($staticPage->key == 'message_image'): ?> name="message_image"
                                    <?php elseif($staticPage->key == 'desc_image'): ?> name="desc_image" <?php endif; ?>
                                    id="img-preview-tag" type="file" onchange="readImg(this, '#img-preview-<?php echo e($staticPage->id); ?>');">
                            <br>
                            <img id="img-preview-<?php echo e($staticPage->id); ?>" alt="" style="height: 50px;" src="<?php echo e(asset($staticPage->photo->path)); ?>">
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="box-footer">
                <button type="submit" class="btn btn-primary"><?php echo e(trans('admin.save')); ?></button>
            </div>

        </div>
        <br>
        <?php echo Form::close(); ?>




    </div><!-- /.box -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app_admin',[
                                'page_header'       => trans('admin.site'),
                                'page_description'  => trans('admin.static_pages')
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\real-estate\resources\views/admin/static pages/index_edit.blade.php ENDPATH**/ ?>