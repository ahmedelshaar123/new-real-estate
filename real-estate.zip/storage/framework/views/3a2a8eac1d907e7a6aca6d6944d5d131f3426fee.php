<?php $__env->startSection('content'); ?>
    <div class="ibox-content">
        <div <?php if(app()->getLocale() == 'ar'): ?>  class="pull-right" <?php else: ?> class="pull-left" <?php endif; ?>>
            <a href="<?php echo e(route('featured-estates.create')); ?>" class="btn btn-primary">
                <i class="fa fa-plus"></i><?php echo e(trans('admin.add')); ?>

            </a>
        </div>
        <hr>
        <div class="box-body">
            <?php if(count($feat_estates)): ?>
                <div class="table-responsive">
                    <table class="data-table table table-bordered" id="table1">
                        <thead>
                        <th class="text-center">#</th>
                        <th class="text-center"><?php echo e(trans('admin.title')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.address')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.images')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.edit')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.delete')); ?></th>

                        </thead>
                        <tbody id="ajax_search">
                        <?php $__currentLoopData = $feat_estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feat_estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="removable<?php echo e($feat_estate->id); ?>">
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td class="text-center"><?php echo e($feat_estate->$title); ?></td>
                                <td class="text-center"><?php echo e($feat_estate->$address); ?></td>
                                <td class="text-center">
                                    <?php $__currentLoopData = $feat_estate->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="<?php echo e(asset($photo->path)); ?>"
                                         alt="" style="height: 50px;">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>

                                <td class="text-center"><a href="<?php echo e(route('featured-estates.edit', $feat_estate->id)); ?>"
                                                           class="btn btn-xs btn-success"><i class="fa fa-edit"></i></a>
                                </td>
                                <td class="text-center">
                                    <button data-token="<?php echo e(csrf_token()); ?>"
                                            data-route="<?php echo e(URL::route('featured-estates.destroy',$feat_estate->id)); ?>"
                                            type="button" class="destroy btn btn-danger btn-xs"><i
                                            class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </div>
        <div class="text-center">
            <?php echo $feat_estates->render(); ?>

        </div>
        <?php else: ?>
            <div class="col-md-4 col-md-offset-4">
                <div class="alert alert-info md-blue text-center"><?php echo e(trans('admin.no_data')); ?></div>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin',[
            'page_header'       => trans('admin.site'),
            'page_description'       => trans('admin.feat'),

                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\real-estate\resources\views/admin/featured estates/index.blade.php ENDPATH**/ ?>