<?php $__env->startSection('content'); ?>
    <div class="ibox-content">
        <div <?php if(app()->getLocale() == 'ar'): ?>  class="pull-right" <?php else: ?> class="pull-left" <?php endif; ?>>
            <a href="<?php echo e(route('services.create')); ?>" class="btn btn-primary">
                <i class="fa fa-plus"></i><?php echo e(trans('admin.add')); ?>

            </a>
        </div>
        <hr>
        <div class="box-body">
            <?php if(count($services)): ?>
                <div class="table-responsive">
                    <table class="data-table table table-bordered" id="table1">
                        <thead>
                        <th class="text-center">#</th>
                        <th class="text-center"><?php echo e(trans('admin.title')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.desc')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.image')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.icon')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.edit')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.delete')); ?></th>

                        </thead>
                        <tbody id="ajax_search">
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="removable<?php echo e($service->id); ?>">
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td class="text-center"><?php echo e($service->$title); ?></td>
                                <td class="text-center"><?php echo $service->$desc; ?></td>
                                <td class="text-center">
                                    <img src="<?php echo e(asset($service->photo->path)); ?>"
                                         alt="" style="height: 50px;">
                                </td>
                                <td class="text-center">
                                    <img src="<?php echo e(asset($service->photo->icon)); ?>"
                                         alt="" style="height: 50px;">
                                </td>

                                <td class="text-center"><a href="<?php echo e(route('services.edit', $service->id)); ?>"
                                                           class="btn btn-xs btn-success"><i class="fa fa-edit"></i></a>
                                </td>
                                <td class="text-center">
                                    <button data-token="<?php echo e(csrf_token()); ?>"
                                            data-route="<?php echo e(URL::route('services.destroy',$service->id)); ?>"
                                            type="button" class="destroy btn btn-danger btn-xs"><i
                                            class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </div>
        <div class="text-center">
            <?php echo $services->render(); ?>

        </div>
        <?php else: ?>
            <div class="col-md-4 col-md-offset-4">
                <div class="alert alert-info md-blue text-center"><?php echo e(trans('admin.no_data')); ?></div>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin',[
            'page_header'       => trans('admin.site'),
            'page_description'       => trans('admin.services'),

                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\real-estate\resources\views/admin/services/index.blade.php ENDPATH**/ ?>