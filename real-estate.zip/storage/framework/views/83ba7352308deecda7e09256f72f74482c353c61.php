<?php $__env->startSection('content'); ?>
    <div class="ibox-content">
        <div <?php if(app()->getLocale() == 'ar'): ?>  class="pull-right" <?php else: ?> class="pull-left" <?php endif; ?>>
            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary">
                <i class="fa fa-plus"></i><?php echo e(trans('admin.add')); ?>

            </a>
        </div>
        <hr>
        <div class="box-body">
            <?php if(count($roles)): ?>
                <div class="table-responsive">
                    <table class="data-table table table-bordered">
                        <thead>
                        <th class="text-center">#</th>
                        <th class="text-center"><?php echo e(trans('admin.name')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.permissions')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.edit')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.delete')); ?></th>

                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="removable<?php echo e($role->id); ?>">
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td class="text-center"><?php echo e($role->name); ?></td>
                                <td class="text-center">
                                    <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($loop->last ? trans("admin.$permission->name") : trans("admin.$permission->name") . ' - '); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <?php if($role->name != 'Super Admin'): ?>
                                <td class="text-center"><a href="<?php echo e(route('roles.edit',$role->id)); ?>"
                                                           class="btn btn-xs btn-success"><i class="fa fa-edit"></i></a>
                                </td>
                                <td class="text-center">
                                    <button data-token="<?php echo e(csrf_token()); ?>"
                                            data-route="<?php echo e(URL::route('roles.destroy',$role->id)); ?>"
                                            type="button" class="destroy btn btn-danger btn-xs"><i
                                            class="fa fa-trash-o"></i></button>
                                <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </div>
        <div class="text-center">
            <?php echo $roles->render(); ?>

        </div>
        <?php else: ?>
            <div class="col-md-4 col-md-offset-4">
                <div class="alert alert-info md-blue text-center"><?php echo e(trans('admin.no_data')); ?></div>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin',[
            'page_header'       => trans('admin.site'),
            'page_description'       => trans('admin.roles'),

                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\real-estate\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>