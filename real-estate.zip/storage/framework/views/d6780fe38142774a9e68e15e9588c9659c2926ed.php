<?php $__env->startSection('content'); ?>
    <div class="ibox-content">
        <div <?php if(app()->getLocale() == 'ar'): ?>  class="pull-right" <?php else: ?> class="pull-left" <?php endif; ?>>
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">
                <i class="fa fa-plus"></i><?php echo e(trans('admin.add')); ?>

            </a>
        </div>
        <hr>
        <div class="box-body">

                <div class="table-responsive">
                    <table class="data-table table table-bordered">
                        <thead>
                        <th class="text-center">#</th>
                        <th class="text-center"><?php echo e(trans('admin.name')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.email')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.roles')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.edit')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.delete')); ?></th>

                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="removable<?php echo e($user->id); ?>">
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td class="text-center"><?php echo e($user->name); ?></td>
                                <td class="text-center"><?php echo e($user->email); ?></td>
                                <td class="text-center">
                                    <?php if(!empty($user->getRoleNames())): ?>
                                        <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($loop->last ? $v : $v . ' - '); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><a href="<?php echo e(route('users.edit',$user->id)); ?>"
                                                           class="btn btn-xs btn-success"><i class="fa fa-edit"></i></a>
                                </td>
                                <?php if(!$user->hasRole('Super Admin')): ?>
                                    <td class="text-center">
                                        <button data-token="<?php echo e(csrf_token()); ?>"
                                                data-route="<?php echo e(URL::route('users.destroy',$user->id)); ?>"
                                                type="button" class="destroy btn btn-danger btn-xs"><i
                                                class="fa fa-trash-o"></i></button>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </div>
        <div class="text-center">
            <?php echo $users->render(); ?>

        </div>





    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin',[
            'page_header'       => trans('admin.site'),
            'page_description'       => trans('admin.users'),

                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\real-estate\resources\views/admin/users/index.blade.php ENDPATH**/ ?>