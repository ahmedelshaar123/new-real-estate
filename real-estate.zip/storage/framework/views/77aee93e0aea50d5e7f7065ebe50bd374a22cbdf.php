<?php $__env->startSection('content'); ?>
    <div class="ibox-content">
        <div class="box-body">
            <?php if(count($subscribers)): ?>
                <div class="table-responsive">
                    <table class="data-table table table-bordered" id="table1">
                        <thead>
                        <th class="text-center">#</th>
                        <th class="text-center"><?php echo e(trans('admin.email')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.delete')); ?></th>
                        </thead>
                        <tbody id="ajax_search">
                        <?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="removable<?php echo e($subscriber->id); ?>">
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td class="text-center"><?php echo e($subscriber->email); ?></td>
                                <td class="text-center">
                                    <button id="<?php echo e($subscriber->id); ?>" data-token="<?php echo e(csrf_token()); ?>"
                                            data-route="<?php echo e(route('subscribers.destroy',$subscriber->id)); ?>"
                                            type="button" class="destroy btn btn-danger btn-xs"><i
                                            class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </div>
        <div class="text-center">
            <?php echo $subscribers->render(); ?>

        </div>
        <?php else: ?>
            <div class="col-md-4 col-md-offset-4">
                <div class="alert alert-info md-blue text-center"><?php echo e(trans('admin.no_data')); ?></div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin',[
         'page_header'       => trans('admin.site'),
         'page_description'       => trans('admin.subscribers')
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\real-estate\resources\views/admin/email subscriptions/index.blade.php ENDPATH**/ ?>