<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--favicons -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('uploads/logo.png')); ?>"/>
    <link href="<?php echo e(asset('uploads/logo.png')); ?>" rel="apple-touch-icon">
    <!--favicons -->
    <title> <?php echo e(trans('admin.site')); ?> | <?php echo e(trans('admin.db')); ?> </title>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link href="<?php echo e(asset('inspina/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('inspina/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('inspina/Ionicons/css/ionicons.min.css')); ?>">
    <link href="<?php echo e(asset('inspina/css/animate.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('inspina/js/plugins/select2/select2.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('inspina/js/plugins/sweetalert/sweetalert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('inspina/js/plugins/bootstrap-fileinput/css/fileinput.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('inspina/js/plugins/lightbox2/css/lightbox.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css">
    <link href="<?php echo e(asset('inspina/css/style.css')); ?>" rel="stylesheet">
    <?php if(app()->getLocale() == 'ar'): ?>
        <link href="<?php echo e(asset('inspina/css/bootstrap-rtl.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('inspina/css/inspina-rtl.css')); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(asset('inspina/css/style.css')); ?>" rel="stylesheet">
    <?php endif; ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
<div id="wrapper">
    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                        
                        <span>
                           <p><?php echo e(trans('admin.welcome') . ' ' . auth()->user()->name); ?></p>
                         </span>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear">






                            </span>
                        </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            
                            
                            <li>
                                <script type="">
                                    function submitSidebarSignout() {
                                        document.getElementById('signoutSidebar').submit();
                                    }
                                </script>
                                <?php echo Form::open(['method' => 'post', 'url' => url('logout'),'id'=>'signoutForm','id'=>'signoutSidebar']); ?>

                                <?php echo Form::close(); ?>

                                <a href="<?php echo e(route('logout')); ?>" onclick="submitSidebarSignout()"><?php echo e(trans('admin.logout')); ?></a>
                            </li>
                        </ul>
                    </div>
                    <div class="logo-element"><?php echo e(config('app.name')); ?></div>
                </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/home')); ?>">
                            <i class="fa fa-home"></i>
                            <span class="nav-label"><?php echo e(trans('admin.home')); ?></span>
                        </a>
                    </li>

                    
                    <li>
                        <a href="<?php echo e(url('admin/top-sliders')); ?>">
                            <i class="fa fa-sliders"></i>
                            <span class="nav-label"><?php echo e(trans('admin.top')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/company-team')); ?>">
                            <i class="fa fa-users"></i>
                            <span class="nav-label"><?php echo e(trans('admin.team')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/featured-estates')); ?>">
                            <i class="fa fa-building-o"></i>
                            <span class="nav-label"><?php echo e(trans('admin.feat')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/services')); ?>">
                            <i class="fa fa-hand-o-up"></i>
                            <span class="nav-label"><?php echo e(trans('admin.services')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/posts')); ?>">
                            <i class="fa fa-newspaper-o" aria-hidden="true"></i>
                            <span class="nav-label"><?php echo e(trans('admin.posts')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/partners')); ?>">
                            <i class="fa fa-handshake-o" aria-hidden="true"></i>
                            <span class="nav-label"><?php echo e(trans('admin.partners')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/bottom-sliders')); ?>">
                            <i class="fa fa-sliders" aria-hidden="true"></i>
                            <span class="nav-label"><?php echo e(trans('admin.bot')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/users')); ?>">
                            <i class="fa fa-user-plus" aria-hidden="true"></i>
                            <span class="nav-label"><?php echo e(trans('admin.users')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/roles')); ?>">
                            <i class="fa fa-plus" aria-hidden="true"></i>
                            <span class="nav-label"><?php echo e(trans('admin.roles')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/contacts')); ?>">
                            <i class="fa fa-phone"></i>
                            <span class="nav-label"><?php echo e(trans('admin.contacts')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/subscribers')); ?>">
                            <i class="fa fa-mail-reply-all"></i>
                            <span class="nav-label"><?php echo e(trans('admin.subscribers')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/static-pages')); ?>">
                            <i class="fa fa-paper-plane-o"></i>
                            <span class="nav-label"><?php echo e(trans('admin.static_pages')); ?></span>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(url('admin/settings')); ?>">
                            <i class="fa fa-gears"></i>
                            <span class="nav-label"><?php echo e(trans('admin.settings')); ?></span>
                        </a>
                    </li>
            </ul>
        </div>
    </nav>
    <div id="page-wrapper" class="gray-bg">
        <style>
            span.select2-container {
                z-index: 10050;
                width: 100% !important;
                padding: 0;
            }
            .select2-container .select2-search--inline {
                float: left;
                width: 100%;
            }
        </style>
        <div class="row border-bottom">
            <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                <div class="navbar-header">
                    <a class="navbar-minimalize minimalize-styl-2 btn btn-primary pull-right" href="#"><i
                            class="fa fa-bars"></i> </a>
                    
                    
                    
                    
                    
                </div>
                <ul class="nav navbar-top-links <?php if(app()->getLocale() == 'en'): ?> navbar-right <?php else: ?> navbar-left <?php endif; ?>">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-flag-o"></i> <?php echo e(trans('admin.lang')); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <ul class="menu bg-primary">
                                    <?php if(LaravelLocalization::getCurrentLocale() == 'ar' ): ?>
                                        <li>
                                            <a class="text-white" rel="alternate" hreflang="en"
                                               href="<?php echo e(LaravelLocalization::getLocalizedURL('en', null, [], true)); ?>">
                                                English
                                            </a>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                            <a class="text-white" rel="alternate" hreflang="ar"
                                               href="<?php echo e(LaravelLocalization::getLocalizedURL('ar', null, [], true)); ?>">
                                                العربية
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <script type="">
                            function submitSignout() {
                                document.getElementById('signoutForm').submit();
                            }
                        </script>
                        <?php echo Form::open(['method' => 'post', 'url' => url('logout'),'id'=>'signoutForm']); ?>

                        <?php echo Form::close(); ?>

                        <a href="<?php echo e(route('logout')); ?>" onclick="submitSignout()">
                          <i class="fa fa-sign-out"></i><?php echo e(trans('admin.logout')); ?>

                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <section class="content-header">
            <h1>
                <?php echo e($page_header ?? trans('admin.site')); ?>

                <small><?php echo $page_description ?? ''; ?></small>
            </h1>
        </section>
        <div class="wrapper wrapper-content">
            <div class="row">



                <div class="col-lg-12">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
            <div class="footer">
                <div>
                    <strong>&copy;</strong><?php echo e(trans('admin.all_rights_reserved')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Mainly scripts -->
<script src="<?php echo e(asset('inspina/js/jquery-2.1.1.js')); ?>"></script>
<script src="<?php echo e(asset('inspina/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('inspina/js/plugins/metisMenu/jquery.metisMenu.js')); ?>"></script>
<script src="<?php echo e(asset('inspina/js/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<!-- Custom and plugin javascript -->
<script src="<?php echo e(asset('inspina/js/inspinia.js')); ?>"></script>
<script src="<?php echo e(asset('inspina/js/plugins/pace/pace.min.js')); ?>"></script>
<script src="<?php echo e(asset('inspina/js/plugins/jquery-confirm/jquery.confirm.min.js')); ?>"></script>
<script src="<?php echo e(asset('inspina/js/plugins/select2/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('inspina/js/plugins/sweetalert/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('inspina/js/plugins/bootstrap-fileinput/js/fileinput.min.js')); ?>"></script>
<script src="<?php echo e(asset('inspina/js/plugins/bootstrap-fileinput/js/fileinput_locale_ar.js')); ?>"></script>
<script src="<?php echo e(asset('inspina/js/plugins/lightbox2/js/lightbox.min.js')); ?>"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script
    src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<style>
    .swal2-popup {
        font-size: 1.5rem !important;
    }
</style>
<script>
    function readImg(input, img) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $(img).attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<script>
    function previewImages(input) {

        var preview = document.querySelector('#preview');

        if (input.files) {
            [].forEach.call(input.files, readAndPreview);
        }

        function readAndPreview(file) {

            // Make sure `file.name` matches our extensions criteria
            if (!/\.(jpe?g|png|gif)$/i.test(file.name)) {
                return alert(file.name + " is not an image");
            } // else...

            var reader = new FileReader();

            reader.addEventListener("load", function() {
                var image = new Image();
                image.height = 50;
                image.title  = file.name;
                image.src    = this.result;
                preview.appendChild(image);
            });

            reader.readAsDataURL(file);

        }

    }

    // document.querySelector('#multi-imgs-tag').addEventListener("change", previewImages);
</script>
<?php if(session()->has('key')): ?>
<script>
        // setTimeout(function(){
        //     $("div.alert").remove();
        // }, 2000 ); // 2 secs
        Swal.fire({
            title: '<?php echo e(session()->get('key')); ?>',
        });
        location.reload();
</script>
<?php endif; ?>
<script>
    $(document).on('click', '.destroy', function () {
        var route = $(this).attr('data-route');
        var elem = $(this).parent('td').parent('tr');
        var token = $(this).attr('data-token');
        Swal.fire({
            title: "<?php echo e(trans('admin.sure')); ?>",
            imageUrl: "<?php echo e(asset('uploads/logo.png')); ?>",
            text: "<?php echo e(trans('admin.once_deleted')); ?>",
            showCancelButton: true,
            showConfirmButton: true,
        })
            .then((willDelete) => {
                if (willDelete.value) {
                    $.ajax({
                        url : route,
                        type : "POST",
                        data : {'_method' : 'DELETE', _token : token},
                        dataType: 'json',
                        success: function(response){
                            if(response === 'delete'){
                                elem.remove();
                                Swal.fire({
                                    icon: 'success',
                                    title: "<?php echo e(trans('admin.success_op')); ?>",
                                    text : "<?php echo e(trans('admin.deleted')); ?>",
                                });
                            }
                            else if(response === 'not-delete'){
                                Swal.fire({
                                    icon: 'error',
                                    title: "<?php echo e(trans('admin.cant_del')); ?>",
                                });
                            }

                        },
                    })
                } else {
                    Swal.fire({
                        icon: 'info',
                        title:"<?php echo e(trans('admin.cancelled')); ?>",
                    });
                }
            });

    });
</script>
<script src="https://cdn.tiny.cloud/1/ue2vr7a42s2iuoqlxjebdb6u4zpnq2ml4nthmk3ftvuzc53f/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<script>
    tinymce.init({
        selector: '.myTextArea'
    });
</script>















<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
<script>
    $(document).ready( function () {
        $('#table1').DataTable(
            {
                searching: true,
                paging: false,
                //scrollY: 200
                //deferRender: true
                "info": false,
                "ordering": false,
                //"processing": true
                language: {
                    search: '<?php echo e(trans('admin.search_here')); ?>',
                }
            }
        );
    });
</script>
<script>
    $(document).ready( function () {
        <?php if(app()->getLocale() == 'ar'): ?>
            $('#table1_filter').css({'float':'right'})
        <?php else: ?>
            $('#table1_filter').css({'float':'left'})
        <?php endif; ?>
    });
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\real-estate\resources\views/layouts/app_admin.blade.php ENDPATH**/ ?>