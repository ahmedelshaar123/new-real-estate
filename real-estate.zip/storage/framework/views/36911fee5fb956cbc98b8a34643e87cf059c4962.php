<?php $__env->startSection('content'); ?>
    <div class="ibox-content">
        <div class="box-body">
            <?php if(count($contacts)): ?>
                <div class="table-responsive">
                    <table class="data-table table table-bordered" id="table1">
                        <thead>
                        <th class="text-center">#</th>
                        <th class="text-center"><?php echo e(trans('admin.name')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.email')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.phone')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.title')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.message')); ?></th>
                        <th class="text-center"><?php echo e(trans('admin.delete')); ?></th>
                        </thead>
                        <tbody id="ajax_search">
                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="removable<?php echo e($contact->id); ?>">
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td class="text-center"><?php echo e($contact->name); ?></td>
                                <td class="text-center"><?php echo e($contact->email); ?></td>
                                <td class="text-center"><?php echo e($contact->phone); ?></td>
                                <td class="text-center"><?php echo e($contact->title); ?></td>
                                <td class="text-center"><?php echo e($contact->message); ?></td>
                                <td class="text-center">
                                    <button id="<?php echo e($contact->id); ?>" data-token="<?php echo e(csrf_token()); ?>"
                                            data-route="<?php echo e(route('contacts.destroy',$contact->id)); ?>"
                                            type="button" class="destroy btn btn-danger btn-xs"><i
                                            class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </div>
        <div class="text-center">
            <?php echo $contacts->render(); ?>

        </div>
        <?php else: ?>
            <div class="col-md-4 col-md-offset-4">
                <div class="alert alert-info md-blue text-center"><?php echo e(trans('admin.no_data')); ?></div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin',[
         'page_header'       => trans('admin.site'),
         'page_description'       => trans('admin.contacts')
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\real-estate\resources\views/admin/contacts/index.blade.php ENDPATH**/ ?>