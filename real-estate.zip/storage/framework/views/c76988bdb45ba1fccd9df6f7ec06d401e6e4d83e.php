<?php $__env->startSection('content'); ?>
    <div class="box">
    <?php echo $__env->make('layouts.partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- form start -->
        <?php echo Form::model($top_slider,[
                                'action'=>['Admin\TopSliderController@update', $top_slider->id],
                                'id'=>'myForm',
                                'role'=>'form',
                                'method'=>'PUT',
                                'files'=>true
                                ]); ?>

        <div class="box-body">
            <div class="form-group">
                <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label for="title"><?php echo e(trans("admin.title_$key")); ?></label>
                    <?php echo Form::text("title_$key",null,[
                        'class'=>'form-control',

                    ]); ?>

                    <br>
                    <label for="desc"><?php echo e(trans("admin.desc_$key")); ?></label>
                    <?php echo Form::textarea("desc_$key",null,[
                        'class'=>'form-control myTextArea',
                        'rows'=>'15',
                    ]); ?>

                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <label for="link"><?php echo e(trans("admin.link")); ?></label>
                <?php echo Form::url("link",null,[
                        'class'=>'form-control',

                ]); ?>

                <br>
                <label for="image"><?php echo e(trans('admin.image')); ?></label>
                <input name="image" id="img-preview-tag" type="file" onchange="readImg(this, '#img-preview');">
                <br>
                <img id="img-preview" alt="" style="height: 50px;">
            </div>
        </div>
        <div class="box-footer">
            <button type="submit" class="btn btn-primary"><?php echo e(trans('admin.save')); ?></button>
        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin',[
            'page_header'       => trans('admin.site'),
            'page_description'       => trans('admin.top'),

                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\real-estate\resources\views/admin/top sliders/edit.blade.php ENDPATH**/ ?>