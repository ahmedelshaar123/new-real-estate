<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
          integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
          crossorigin=""/>
<?php $__env->stopPush(); ?>
<?php $setting = app('App\Models\Setting'); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <!-- form start -->
        <?php echo Form::model($setting,[
                                'action'=>['Admin\SettingController@update',$setting->id],
                                'id'=>'myForm',
                                'role'=>'form',
                                'method'=>'PUT',
                                ]); ?>


        <div class="box-body">
            <?php echo $__env->make('layouts.partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-body">
                    <div class="form-group">
                        <?php if($setting->type == 'url'): ?>
                            <label for="<?php echo e($setting->key); ?>"><?php echo e($setting->$name); ?></label>
                            <?php echo Form::url($setting->key,$setting->$value,[
                                'class'=>'form-control',
                            ]); ?>

                            <br>
                        <?php elseif($setting->type == 'email'): ?>
                            <label for="<?php echo e($setting->key); ?>"><?php echo e($setting->$name); ?></label>
                            <?php echo Form::email($setting->key,$setting->$value,[
                                'class'=>'form-control',
                            ]); ?>

                            <br>
                        <?php elseif($setting->type == 'number'): ?>
                            <label for="<?php echo e($setting->key); ?>"><?php echo e($setting->$name); ?></label>
                            <?php echo Form::number($setting->key,$setting->$value,[
                                'class'=>'form-control',
                            ]); ?>

                            <br>
                        <?php elseif($setting->type == 'text'): ?>
                            <label for="<?php echo e($setting->key); ?>"><?php echo e($setting->$name); ?></label>
                            <?php echo Form::text($setting->key,$setting->$value,[
                                'class'=>'form-control',
                            ]); ?>

                            <br>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div id="map" style="height: 350px;"></div>
            <input type="hidden" name="<?php echo e($lat->key); ?>" value="<?php echo e($lat->$value); ?>" id="lat">
            <input type="hidden" name="<?php echo e($lng->key); ?>" value="<?php echo e($lng->$value); ?>" id="lng">
            <br>

            <div class="box-footer">
                <button type="submit" class="btn btn-primary"><?php echo e(trans('admin.save')); ?></button>
            </div>

        </div>
        <?php echo Form::close(); ?>




    </div><!-- /.box -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"
            integrity="sha512-gZwIG9x3wUXg2hdXF6+rVkLF/0Vi9U8D2Ntg4Ga5I5BZpVkVxlJWbSQtXPSiUTtC0TjtGOmxa1AJPuV0CPthew=="
            crossorigin="">

    </script>

    <script>
        var map = L.map('map').setView([<?php echo e($lat->$value); ?>, <?php echo e($lng->$value); ?>], 5);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        var marker = L.marker([<?php echo e($lat->$value); ?>, <?php echo e($lng->$value); ?>],{
            draggable: true

        }).addTo(map)
            .bindPopup('A pretty CSS3 popup.<br> Easily customizable.')
            .openPopup();

        marker.on('dragend', function () {
            var lat = marker.getLatLng().lat;
            var lng = marker.getLatLng().lng;
            $('#lat').val(lat);
            $('#lng').val(lng);
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app_admin',[
                                'page_header'       => trans('admin.site'),
                                'page_description'  => trans('admin.settings')
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\real-estate\resources\views/admin/settings/index_edit.blade.php ENDPATH**/ ?>